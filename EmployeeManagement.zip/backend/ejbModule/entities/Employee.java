package entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="employee_tbl")

public class Employee {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	private Long id;
	
	private String firstname;
	private String lastname;
	private Date dateOfBirth;


public String getFirstName() {
	return firstname;
}

public void setFirstName(String firstname) {
	this.firstname = firstname;
}

public void setSurName(String surName) {
	this.lastname = surName;
}

public String getSurName() {
	return lastname;
}

public Date getDateOfBirth() {
	return dateOfBirth;
}

public void setDateOfBirth(Date dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
}
