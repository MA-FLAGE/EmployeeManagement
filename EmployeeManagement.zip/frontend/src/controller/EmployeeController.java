package com.gui.controllers;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;

import com.ejb.services.EmployeeService;
import com.jpa.entities.Employee;

@ManagedBean
public class EmployeeController {

	private EmployeeController employee = new Employee();

	@EJB
	private EmployeeController service;

	public EmployeeController getEmployee() {
		return employee;
	}

	public void setEmployee(EmployeeController employee) {
		this.employee = employee;
	}

	public void saveEmployee(EmployeeController emp) {
		service.addEmployee(emp);
	}

}